 <?php 
 include('connect.php');
 ?>

 
        <div class="left-sidebar">
            
            <div class="scroll-sidebar">
                
                <nav class="sidebar-nav">
                    <ul id="sidebarnav">
                        <li class="nav-devider"></li>
                        <li class="nav-label">Home</li>
                        <li> <a href="index.php" aria-expanded="false"><i class="fa fa-window-maximize"></i>Dashboard</a>
                        </li>

                         <!-- <li class="nav-label">Attendence</li> -->
                        <li> <a class="has-arrow" href="#" aria-expanded="false"><i class="fa fa-clock-o"></i><span class="hide-menu">Attendence Management</span></a>
                            <ul aria-expanded="false" class="collapse">
                                <li><a href="add_attendence.php">Add Attendence</a></li>
                                <li><a href="view_attendence.php">View Attendence</a></li>
                               
                            </ul>
                        </li>

                         <!-- <li class="nav-label">Teacher</li> -->
                        <li> <a class="has-arrow" href="#" aria-expanded="false"><i class="fa fa-user"></i><span class="hide-menu">Teacher Management</span></a>
                            <ul aria-expanded="false" class="collapse">
                                <li><a href="add_teacher.php">Add Teacher</a></li>
                                <li><a href="view_teacher.php">View Teacher</a></li>
                            </ul>
                        </li>

                         <!-- <li class="nav-label">Student</li> -->
                        <li> <a class="has-arrow" href="#" aria-expanded="false"><i class="fa fa-users"></i><span class="hide-menu">Student Management</span></a>
                            <ul aria-expanded="false" class="collapse">
                                <li><a href="add_student.php">Add Student</a></li>
                                <li><a href="view_student.php">View Student</a></li>
                            </ul>
                        </li>

                         <!-- <li class="nav-label">Subject</li> -->
                        <li> <a class="has-arrow" href="#" aria-expanded="false"><i class="fa fa-newspaper-o"></i><span class="hide-menu">Subject Management</span></a>
                            <ul aria-expanded="false" class="collapse">
                                <li><a href="add_subject.php">Add Subject</a></li>
                                <li><a href="view_subject.php">View Subject</a></li>
                            </ul>
                        </li>

                      

                    

                         <!-- <li class="nav-label">Class</li> -->
                        <li> <a class="has-arrow" href="#" aria-expanded="false"><i class="fa fa-home"></i><span class="hide-menu">Class Management</span></a>
                            <ul aria-expanded="false" class="collapse">
                                <li><a href="add_class.php">Add Class</a></li>
                           
                                <li><a href="view_class.php">View Class</a></li>
                            </ul>
                        </li>
                   
                   
                  

                
                         

                         <li> <a class="has-arrow" href="#" aria-expanded="false"><i class="fa fa-cog"></i><span class="hide-menu">Setting</span></a>
                            <ul aria-expanded="false" class="collapse">
                               
                               <li><a href="manage_website.php">Appearance Management</a></li>
                             
                              <li><a href="email_config.php">Email Management</a></li>
                               
                              
                            </ul>
                        </li> 
                    

                         <li class="nav-label">Reports</li> 
                        <li>  <a class="has-arrow" href="#" aria-expanded="false"><i class="fa fa-file"></i><span class="hide-menu">Report Management</span></a>
                            <ul aria-expanded="false" class="collapse">
                                <li><a href="today_attendence.php">Today's Attendence</a></li>
                                <li><a href="report_attendence.php">Attendence Report</a></li>
                            </ul>
                        </li>
                   

    
                    </ul>   
                </nav>
               </div>
            </div>
           
        </div>
        